SCT_URI = "http://snomed.info/sct"
