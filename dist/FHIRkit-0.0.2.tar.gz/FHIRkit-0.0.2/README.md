# FHIRkit

Handle FHIR resources in a more efficient, and pythonic way
